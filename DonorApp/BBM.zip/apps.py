from django.apps import AppConfig


class DonorappConfig(AppConfig):
    name = 'DonorApp'
